import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT || 3000);
const API_KEY = process.env.OPENAI_API_KEY || '';
const MODEL = process.env.OPENAI_MODEL || 'gpt-6.2-sol';
const MAX_BODY = 1024 * 1024;

const AIDE_INSTRUCTIONS = `당신은 Aide Intelligence의 대화형 의사결정 AI입니다. 사용자가 고민을 일상 언어로 설명하면 대화를 통해 맥락을 파악하고, 2~5개 선택지를 구성한 뒤 아래 수리과학 효용 방정식으로 비교할 수 있도록 수치 추정치를 제안합니다.

수식은 서버가 계산하므로 절대로 점수를 직접 계산하거나 최종 순위를 임의로 만들지 마십시오. 당신은 선택지와 각 요인별 변수값만 제안합니다.

각 선택지에 factors 배열을 2~4개 제공하고, 모든 선택지에서 가능한 한 같은 평가요인 이름·개수·의미를 사용하십시오. 변수 범위: a 0~100, w -0.5~1, b 0.1~100, r 0~100(%), s 0.1~1, adv 0.1~2. alpha와 beta는 각각 0.5~2.

평가값은 반드시 대화의 근거와 합리적인 추정에 기반해야 합니다. 외부 데이터에 접근하지 않았다면 시장 평균·최신 통계·실제 확률을 아는 것처럼 말하지 마십시오. 추정한 변수는 assumptions에 '초기 추정치'라고 적고, 사용자가 확인해야 할 핵심 가정을 분명히 하십시오.

처음 메시지에 핵심 정보가 부족해 의미 있는 비교가 어렵다면 needs_clarification=true로 설정하고, 반드시 질문 하나만 하십시오. 질문은 사용자가 바로 대답할 수 있는 가장 중요한 정보 하나에 집중합니다. 사용자가 이미 충분한 정보를 주었다면 추가 질문을 강요하지 말고 즉시 분석하십시오. 이미 제공된 정보를 다시 묻지 마십시오.

건강·의료 관련 질문에서는 진단이나 치료 변경을 권하지 말고 의료진 확인을 우선하는 안전한 대안을 구성하십시오. 투자·대출·생계 등 중대한 결정은 손실 위험과 불확실성을 명시하고 확정적 수익을 약속하지 마십시오.

항상 아래 JSON 객체 하나만 출력하십시오. 마크다운 코드블록이나 JSON 밖의 문장을 넣지 마십시오.
{
  "reply": "사용자에게 보여줄 자연스러운 한국어 대화 응답",
  "needs_clarification": false,
  "clarifying_question": "추가 질문이 없으면 빈 문자열",
  "decision_title": "결정 과제 제목",
  "alpha": 1.0,
  "beta": 1.0,
  "options": [
    {"name":"선택지 이름","description":"설명","factors":[
      {"name":"평가요인","a":70,"w":0.2,"b":20,"r":20,"s":0.7,"adv":1.0}
    ]}
  ],
  "action_steps": ["1단계 실행 지침","2단계 실행 지침","3단계 실행 지침"],
  "assumptions": ["초기 추정 또는 확인이 필요한 가정"],
  "risks": ["주요 리스크와 불확실성"]
}

needs_clarification=true인 경우 options는 빈 배열이어도 됩니다. 분석할 때 선택지는 2~5개, action_steps는 정확히 3개를 제공하십시오. 사용자에게 친절하고 단정한 한국어로 말하되, 근거 없는 정밀함을 가장하지 마십시오.`;

function send(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
function readBody(req) {
  return new Promise((resolve, reject) => {
    let raw = '';
    req.on('data', chunk => {
      raw += chunk;
      if (raw.length > MAX_BODY) { reject(new Error('요청 본문이 너무 큽니다.')); req.destroy(); }
    });
    req.on('end', () => {
      try { resolve(JSON.parse(raw || '{}')); }
      catch { reject(new Error('JSON 요청 형식이 올바르지 않습니다.')); }
    });
    req.on('error', reject);
  });
}
function extractText(response) {
  if (typeof response.output_text === 'string') return response.output_text;
  const parts = [];
  for (const item of response.output || []) {
    if (item.type === 'message') for (const content of item.content || []) if (content.type === 'output_text') parts.push(content.text || '');
  }
  return parts.join('\n');
}
async function handleAi(messages) {
  if (!API_KEY) throw new Error('OPENAI_API_KEY가 설정되지 않았습니다.');
  const input = messages.map(m => ({ role: m.role, content: m.content }));
  const upstream = await fetch('https://api.openai.com/v1/responses', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${API_KEY}` },
    body: JSON.stringify({ model: MODEL, instructions: AIDE_INSTRUCTIONS, input, text: { format: { type: 'json_object' } } })
  });
  const payload = await upstream.json().catch(() => ({}));
  if (!upstream.ok) {
    const message = payload?.error?.message || `AI 제공자 응답 오류 (${upstream.status})`;
    throw new Error(message);
  }
  const text = extractText(payload);
  if (!text) throw new Error('AI 응답에 텍스트가 없습니다.');
  try { return JSON.parse(text); }
  catch { throw new Error('AI 응답을 JSON으로 읽지 못했습니다. 다시 전송해 주세요.'); }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);
  if (req.method === 'GET' && url.pathname === '/api/status') {
    return send(res, 200, { aiConnected: Boolean(API_KEY), model: MODEL, version: '0.2.0' });
  }
  if (req.method === 'POST' && url.pathname === '/api/chat') {
    try {
      const body = await readBody(req);
      if (!Array.isArray(body.messages) || !body.messages.length) return send(res, 400, { error: 'messages 배열이 필요합니다.' });
      const messages = body.messages.slice(-18).filter(m => ['user', 'assistant'].includes(m.role) && typeof m.content === 'string' && m.content.trim()).map(m => ({ role: m.role, content: m.content.slice(0, 12000) }));
      if (!messages.length || messages[messages.length - 1].role !== 'user') return send(res, 400, { error: '마지막 메시지는 사용자 메시지여야 합니다.' });
      const data = await handleAi(messages);
      return send(res, 200, { data });
    } catch (error) {
      return send(res, 502, { error: error.message || 'AI 요청 처리에 실패했습니다.' });
    }
  }
  if (req.method === 'GET' && (url.pathname === '/' || url.pathname === '/index.html')) {
    res.writeHead(200, { 'Content-Type': 'text/html; charset=utf-8', 'Cache-Control': 'no-store' });
    return fs.createReadStream(path.join(__dirname, 'index.html')).pipe(res);
  }
  if (req.method === 'GET' && url.pathname === '/favicon.ico') { res.writeHead(204); return res.end(); }
  res.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  res.end('Not found');
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Aide Intelligence v0.2.0 running on http://localhost:${PORT}`);
  console.log(API_KEY ? `AI mode enabled (${MODEL})` : 'Local demo mode (set OPENAI_API_KEY to enable AI chat)');
});
