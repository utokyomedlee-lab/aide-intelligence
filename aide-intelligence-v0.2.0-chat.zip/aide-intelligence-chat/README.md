# Aide Intelligence v0.2.0 — Conversational Decision Agent

A chat-first Korean decision assistant. Users describe a decision in natural language; the application responds conversationally, proposes alternatives and factor estimates, calculates the supplied Aide utility equation, and displays a ranked briefing in the chat.

## Run locally

Requirements: Node.js 20 or newer.

```bash
npm start
```

Open `http://localhost:3000`.

## Modes

### Local demo mode

Works without an API key. A transparent, rule-based local analyzer selects a domain template (business, career, product development, study, health, or general decisions), proposes illustrative values, and runs the Aide formula. It is a functional prototype, not a generative LLM and not a live-data service.

### AI chat mode

Set `OPENAI_API_KEY` as a server environment variable and restart the server. You may override `OPENAI_MODEL` (default: `gpt-6.2-sol`). The server sends the conversation to the OpenAI Responses API and receives an Aide-specific JSON decision proposal. The browser never receives the API key.

PowerShell example:

```powershell
$env:OPENAI_API_KEY="YOUR_KEY"
$env:OPENAI_MODEL="gpt-6.2-sol"
npm start
```

macOS/Linux example:

```bash
export OPENAI_API_KEY="YOUR_KEY"
export OPENAI_MODEL="gpt-6.2-sol"
npm start
```

API access and billing are separate from ChatGPT subscriptions. Keep the key private and configure it only in the server environment.

## Features

- ChatGPT-style conversational interface.
- Separate conversation history stored in the current browser.
- AI mode through a server-side OpenAI Responses API adapter.
- Local rule-based fallback without a key.
- Aide formula calculation performed by application code, not invented by the model.
- 2–5 alternatives with factor-level contribution detail.
- α / β parameters, ranked comparison, assumptions, risks, and three action steps.
- JSON conversation export and print / PDF.
- Responsive desktop and mobile layout.

## Formula implementation

For each factor:

`(alpha * ln(1 + max(0,a) * (1+w))) / (beta * ln(1 + max(0,b) * (1+R/100)) + 1e-5) * S * A`

Each factor contribution is rounded to four decimal places before summing, following the supplied specification.

## Important limitations

- The local demo uses transparent sample templates, not a trained AI model or external big-data source.
- AI mode proposes variables from the conversation; these are still estimates unless supported by verifiable source data.
- The app does not currently browse the web, connect market/public databases, or validate real-world facts.
- The score is a relative model output, not a success probability or guarantee. Health, legal, financial, and safety decisions need domain-appropriate professional review.
- Keep comparable factor definitions and counts across options to avoid structural scoring bias.

## Files

- `index.html` — chat-first UI and browser-side formula engine
- `server.mjs` — static server and optional server-side AI adapter
- `package.json` — run script and Node version
- `.env.example` — environment-variable template (do not put real secrets in source control)
